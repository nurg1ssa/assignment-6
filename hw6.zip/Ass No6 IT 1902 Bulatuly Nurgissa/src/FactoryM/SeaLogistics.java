package FactoryMethod;

public class SeaLogistics extends LogisticsApp{
    @Override
    public Transport CreateTransport() {
        return new Ship();
    }
}
