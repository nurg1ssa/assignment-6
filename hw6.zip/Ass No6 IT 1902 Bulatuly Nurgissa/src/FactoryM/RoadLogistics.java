package FactoryMethod;

public class RoadLogistics extends LogisticsApp {
    @Override
    public Transport CreateTransport() {
        return new Truck();
    }
}
