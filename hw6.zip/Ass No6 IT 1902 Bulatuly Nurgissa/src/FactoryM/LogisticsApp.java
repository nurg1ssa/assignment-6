package FactoryMethod;

public abstract class LogisticsApp {
    public void planDelivery(){
        Transport t = CreateTransport();
        t.deliver();
    }

    public abstract Transport CreateTransport();

}

