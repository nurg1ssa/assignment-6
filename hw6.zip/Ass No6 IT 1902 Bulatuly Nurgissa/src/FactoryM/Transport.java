package FactoryMethod;
public interface Transport{
 void deliver();
}