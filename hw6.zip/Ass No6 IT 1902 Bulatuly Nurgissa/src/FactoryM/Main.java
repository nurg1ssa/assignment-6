package FactoryMethod;

import java.util.Scanner;

public class Main {
    private static LogisticsApp logisticsApp;

    public static void main(String[] args) {
        System.out.println("Write type of Logistics or type of Transport:");

        Scanner in = new Scanner(System.in);

        chottomatte(in.nextLine());

        logisticsApp.planDelivery();
    }

    public static void chottomatte(String type){
        type = type.toLowerCase();

        switch (type) {
            case "ship":
            case "sea":
                logisticsApp = new SeaLogistics();
                break;
            case "truck":
            case "road":
                logisticsApp = new RoadLogistics();
                break;
            default:
                System.out.println("Wrong Input");
        }

    }
}
