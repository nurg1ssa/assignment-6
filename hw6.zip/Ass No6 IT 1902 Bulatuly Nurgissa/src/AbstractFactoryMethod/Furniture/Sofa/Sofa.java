package AbstractFactoryMethod.Furniture.Sofa;

public interface Sofa {
    boolean hasLegs();
    boolean hasCushion();
    void lieOn();
}
