package AbstractFactoryMethod.Furniture.Chair;

public interface Chair {
    boolean hasLegs();
    void sitOn();
}
