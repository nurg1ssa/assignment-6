package AbstractFactoryMethod.Furniture.CoffeeTable;

public interface CoffeeTable {
    String getShape();
    void onTable();
}
