package AbstractFactoryMethod.FurnitureFactory;

import AbstractFactoryMethod.Furniture.Chair.Chair;
import AbstractFactoryMethod.Furniture.Chair.ModernChair;
import AbstractFactoryMethod.Furniture.CoffeeTable.CoffeeTable;
import AbstractFactoryMethod.Furniture.CoffeeTable.ModernCoffeeTable;
import AbstractFactoryMethod.Furniture.Sofa.Sofa;
import AbstractFactoryMethod.Furniture.Sofa.ModernSofa;

public class ModernFurnitureFactory implements FurnitureFactory{
    public ModernFurnitureFactory() {
    }

    @Override
    public Chair CreateChair() {
        return new ModernChair();
    }

    @Override
    public CoffeeTable CreateCoffeeTable() {
        return new ModernCoffeeTable();
    }

    @Override
    public Sofa CreateSofa() {
        return new ModernSofa();
    }
}
