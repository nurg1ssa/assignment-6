package AbstractFactoryMethod.FurnitureFactory;

import AbstractFactoryMethod.Furniture.Chair.Chair;
import AbstractFactoryMethod.Furniture.Chair.VictorianChair;
import AbstractFactoryMethod.Furniture.CoffeeTable.CoffeeTable;
import AbstractFactoryMethod.Furniture.CoffeeTable.VictorianCoffeeTable;
import AbstractFactoryMethod.Furniture.Sofa.Sofa;
import AbstractFactoryMethod.Furniture.Sofa.VictorianSofa;

public class VictorianFurnitureFactory implements FurnitureFactory{
    public VictorianFurnitureFactory() {
    }

    @Override
    public Chair CreateChair() {
        return new VictorianChair();
    }

    @Override
    public CoffeeTable CreateCoffeeTable() {
        return new VictorianCoffeeTable();
    }

    @Override
    public Sofa CreateSofa() {
        return new VictorianSofa();
    }
}
