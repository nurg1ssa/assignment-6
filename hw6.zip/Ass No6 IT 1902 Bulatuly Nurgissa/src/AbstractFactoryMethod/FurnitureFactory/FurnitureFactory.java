package AbstractFactoryMethod.FurnitureFactory;

import AbstractFactoryMethod.Furniture.Chair.Chair;
import AbstractFactoryMethod.Furniture.CoffeeTable.CoffeeTable;
import AbstractFactoryMethod.Furniture.Sofa.Sofa;

public interface FurnitureFactory {
    Chair CreateChair();
    CoffeeTable CreateCoffeeTable();
    Sofa CreateSofa();
}
