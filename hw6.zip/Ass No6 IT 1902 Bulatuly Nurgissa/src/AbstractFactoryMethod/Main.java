package AbstractFactoryMethod;

import AbstractFactoryMethod.Furniture.Chair.Chair;
import AbstractFactoryMethod.Furniture.CoffeeTable.CoffeeTable;
import AbstractFactoryMethod.Furniture.Sofa.Sofa;
import AbstractFactoryMethod.FurnitureFactory.FurnitureFactory;
import AbstractFactoryMethod.FurnitureFactory.ModernFurnitureFactory;
import AbstractFactoryMethod.FurnitureFactory.VictorianFurnitureFactory;

import java.util.Scanner;

public class Main {
    private static FurnitureFactory factory;
    private static Chair chair;
    private static Sofa sofa;
    private static CoffeeTable coffeeTable;

    public static void implement(String factorytype) {
        factorytype = factorytype.toLowerCase();

        switch (factorytype) {
            case "modern":
                System.out.println("Modern Furniture");
                factory = new ModernFurnitureFactory();
                break;
            case "victorian":
                System.out.println("Victorian Furniture");
                factory = new VictorianFurnitureFactory();
                break;
            default:
                System.out.println("Wrong Input");
        }
        chair = factory.CreateChair();
        sofa = factory.CreateSofa();
        coffeeTable = factory.CreateCoffeeTable();
    }

    public static void use() {
        System.out.println("Chair has legs? " + chair.hasLegs());
        chair.sitOn();

        System.out.println("What is the shape of coffee table? " + coffeeTable.getShape());
        coffeeTable.onTable();

        System.out.println("Does that sofa has cushions? " + sofa.hasCushion());
        System.out.println("Does that sofa has legs? " + sofa.hasLegs());
        sofa.lieOn();
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Write type of furniture:");
        System.out.println("Modern");
        System.out.println("Victorian");
        implement(in.nextLine());
        use();

        System.out.println("\n");
    }
}
