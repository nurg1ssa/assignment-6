package Singleton;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Application {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Database foo = Database.getInstance("jdbc:mysql://localhost:3306/stones?autoReconnect=true&useSSL=false", "root", "123456");
        ResultSet l = foo.query("SELECT * FROM stone");
        System.out.println(foo.toString() +":Address of foo and bar is the same\n");
        while (l.next()){
                String name = l.getString("stone_name");
                double cost =  l.getDouble("stone_cost");
                double weight = l.getDouble("stone_weight");
                System.out.println("       " + name + "       " + cost + "      " + weight );
        }

        Database bar = Database.getInstance("jdbc:mysql://localhost:3306/stones?autoReconnect=true&useSSL=false", "root", "123456");
        ResultSet r = bar.query("SELECT * FROM stone");
        System.out.println("\n\n"+bar.toString() + ":Address of foo and bar is the same\n");
        while (r.next()){
            String name = r.getString("stone_name");
            double cost =  r.getDouble("stone_cost");
            double weight = r.getDouble("stone_weight");
            System.out.println("       " + name + "       " + cost + "      " + weight );
        }

        // The variable `bar` will contain the same object as
        // the variable `foo`.
    }

}
