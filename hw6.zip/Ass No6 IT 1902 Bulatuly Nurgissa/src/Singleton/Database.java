package Singleton;

import java.sql.*;

public class  Database {
    private static Database instance;
    private Connection con;
    private Statement stmt;

    //By default it will connect to my database called stones
    private Database() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        this.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stones?autoReconnect=true&useSSL=false","root","123456");
        this.stmt =  con.createStatement();
    }

    //Connecting to others databases
    private Database(String conURL,String conUser, String conPassword) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        this.con = DriverManager.getConnection( conURL, conUser, conPassword);
        this.stmt =  con.createStatement();
    }

    //Closing connection
    public void Close() throws SQLException {
        con.close();
    }

    public static synchronized Database getInstance(String conURL,String conUser, String conPassword) throws SQLException, ClassNotFoundException {
        if (Database.instance == null)
        Database.instance = new Database();
        return Database.instance;
    }


    public ResultSet query(String query) throws SQLException {
        return Database.instance.getStmt().executeQuery(query);
    }

    //Getters
    public Connection getCon() {
        return con;
    }

    public Statement getStmt() {
        return stmt;
    }

    //Setters
    public void setCon(String conURL,String conUser, String conPassword) throws SQLException {
        this.con = DriverManager.getConnection( conURL, conUser, conPassword);
        setStmt();
    }

    public void setStmt() throws SQLException {
        this.stmt =  con.createStatement();
    }



}

