package Builder.Houses;

public class Walls {
    private String wallType;

    public Walls(String wallType) {
        this.wallType = wallType;
    }

    public String getWallType() {
        return wallType;
    }

    public void setWallType(String wallType) {
        this.wallType = wallType;
    }
}
