package Builder;

import AbstractFactoryMethod.FurnitureFactory.ModernFurnitureFactory;
import AbstractFactoryMethod.FurnitureFactory.VictorianFurnitureFactory;
import Builder.Builders.HouseBuilder;
import Builder.Builders.HouseMapBuilder;
import Builder.Director.Director;
import Builder.Houses.House;
import Builder.Houses.HouseMap;

import java.util.Scanner;

public class Main {
    private static final Director director = new Director();
    private static final HouseBuilder houseBuilder = new HouseBuilder();
    private static final HouseMapBuilder houseMapBuilder = new HouseMapBuilder();

    public static void forDirector(String str){

        str = str.toLowerCase();

        switch (str) {
            case "average":
                System.out.println("Average house and its map");
                director.buildAverageHouse(houseBuilder);
                director.buildAverageHouse(houseMapBuilder);
                break;
            case "large":
                System.out.println("Large house and its map");
                director.buildLargeHouse(houseBuilder);
                director.buildLargeHouse(houseMapBuilder);
                break;
            case "small":
                System.out.println("Small house and its map");
                director.buildSmallHouse(houseBuilder);
                director.buildSmallHouse(houseMapBuilder);
                break;
            default:
                System.out.println("Wrong Input");
        }
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Write type of house:");
        System.out.println("Large");
        System.out.println("Small");
        System.out.println("Average");

        forDirector(in.nextLine());

        House house = houseBuilder.getResult();
        HouseMap houseMap = houseMapBuilder.getResult();

        System.out.println(houseMap.showMap());
    }
}
